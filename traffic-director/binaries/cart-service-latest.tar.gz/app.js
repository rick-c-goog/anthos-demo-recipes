require('@google-cloud/trace-agent').start({
  samplingRate: 0,
  ignoreUrls: [ '^/$' ]
});
const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const {PubSub} = require('@google-cloud/pubsub');
const shopService = require("./services/shop");

const env = process.env.NODE_ENV || 'development';
const app = express();
let isActive = true;

// PubSub setup
const interval = setInterval(() => {
  const pubsubOptions = {};
  if (env === 'development') { pubsubOptions.projectId = process.env.GCLOUD_PROJECT };
  const pubsub = new PubSub();
  const topic = pubsub.topic(process.env.CONTROL_PLANE || 'control-plane');

  function onMessage(message) {
    const data = JSON.parse(message.data);
    if (data.msg === 'get') {
      topic.publish(Buffer.from(JSON.stringify({msg: 'get-response', name: process.env.HOSTNAME, status: isActive})));
    } else if (data.msg === 'set' && data.name === process.env.HOSTNAME) {
      isActive = data.status;
    }

    message.ack();
  }

  topic.subscription(process.env.HOSTNAME)
    .exists()
    .then(data => {
      const exists = data[0];
      if (!exists) {
        return topic.createSubscription(process.env.HOSTNAME)
          .then(d => new Promise(resolve => setTimeout(() => resolve(d[0], 100))));
      }

      return topic.subscription(process.env.HOSTNAME);
    })
    .then(s => s.on('message', onMessage))
    .then(() => topic.publish(Buffer.from(JSON.stringify({ msg: 'get-response', name: process.env.HOSTNAME, status: isActive }))))
    .then(() => clearInterval(interval))
    .then(() => console.log('PubSub created successfully'))
    .catch(e => console.log('An error occurred: ' + e));
}, 10000);

// CORS setup
app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.options("/*", function(req, res, next){
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
  res.send(200);
});

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

/**
 * Main endpoints
 */
app.get('/', (req, res) => res.sendStatus(isActive ? 200 : 500));

app.get('/api/payment', (req, res) => {
  if (isActive) {
    shopService.processPayment().then(response => {
      res.send({
        ...response,
        proxiedBy: 'cart'
      });
    });
  } else {
    res.sendStatus(500);
  }
});

app.get('/api/cart', (req, res) => {
  if (isActive) {
    res.send({
      serviceName: 'cart',
      servedBy: process.env.DATACENTER,
      servedByHost: process.env.HOSTNAME,
      timestamp: (new Date()).toISOString(),
      version: process.env.VERSION ? process.env.VERSION : '1'
    });
  } else {
    res.sendStatus(500);
  }
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = env === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
