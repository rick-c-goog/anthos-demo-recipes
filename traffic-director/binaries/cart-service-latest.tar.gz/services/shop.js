
const fetch = require('node-fetch');

const processPayment = async () => {
  const paymentHost = process.env.PAYMENT_HOST
  return await fetchAsync(`${paymentHost}/api/payment`);
};

async function fetchAsync (url) {
  try {
    let response = await fetch(url);
    return await response.json();
  } catch (e) {
    console.log(`Failed to query backend: ${e}`);
    return { serviceName: 'unknown', servedBy: 'unknown', timestamp: (new Date()).toISOString() };
  }
}
module.exports = {
  processPayment
}